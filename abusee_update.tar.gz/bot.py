#!/usr/bin/env python3
"""
Telegram Bot для VPN-сервиса с оплатой через ЮKassa
"""
import os
import logging
import json
import fcntl
from pathlib import Path
import time
import urllib.request
import urllib.error
import traceback
from datetime import datetime, timedelta
from dotenv import load_dotenv
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup, LabeledPrice, ReplyKeyboardRemove
from telegram.error import BadRequest
from telegram.error import Conflict
from telegram.ext import (
    ApplicationBuilder,
    ContextTypes,
    CommandHandler,
    MessageHandler,
    filters,
    ConversationHandler,
    PreCheckoutQueryHandler,
)
from app.database.database import Base, SessionLocal, engine
from app.services.vpn_service import VPNService
from app.services.xui_client import XUIClient
from app.models.user import User

# Загружаем переменные окружения
load_dotenv()

# Настраиваем логирование
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# Конфигурация бота
TELEGRAM_BOT_TOKEN = (os.getenv("TELEGRAM_BOT_TOKEN") or "").strip()
TELEGRAM_ADMIN_ID = (os.getenv("TELEGRAM_ADMIN_ID") or "").strip()
INSTALLATION_GUIDE_URL = (os.getenv("INSTALLATION_GUIDE_URL") or "").strip()
YOO_PAYMENT_TOKEN = (os.getenv("YOO_PAYMENT_TOKEN") or "").strip()
CURRENCY = "RUB"

# Цены (в копейках!)
PRICE_1_MONTH = 29900  # 299 рублей
PRICE_3_MONTHS = 81000  # 810 рублей

# Состояния разговора
SELECTING_PLAN = 1
CONFIRM_NEW_SUBSCRIPTION = 2
SELECTING_EXTEND_PLAN = 3


#region debug-point yis-setup
_DBG_CACHE = {"url": None, "session": None, "loaded": False}


def _dbg_load_config() -> None:
    if _DBG_CACHE["loaded"]:
        return
    _DBG_CACHE["loaded"] = True

    url = os.getenv("DEBUG_SERVER_URL")
    session = os.getenv("DEBUG_SESSION_ID")
    if url and session:
        _DBG_CACHE["url"] = url
        _DBG_CACHE["session"] = session
        return

    env_path = Path(__file__).with_name(".dbg") / "yookassa-invoice-stuck.env"
    try:
        if not env_path.exists():
            return
        for line in env_path.read_text(encoding="utf-8").splitlines():
            if not line or line.strip().startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k = k.strip()
            v = v.strip()
            if k == "DEBUG_SERVER_URL":
                url = v
            elif k == "DEBUG_SESSION_ID":
                session = v
        _DBG_CACHE["url"] = url
        _DBG_CACHE["session"] = session
    except Exception:
        return


def _dbg(event: str, **fields) -> None:
    _dbg_load_config()
    if not _DBG_CACHE["url"] or not _DBG_CACHE["session"]:
        return
    payload = {
        "ts": time.time(),
        "sessionId": _DBG_CACHE["session"],
        "event": event,
        **fields,
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        _DBG_CACHE["url"],
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=1.5):
            pass
    except Exception:
        return


def _provider_kind(token: str | None) -> str | None:
    if not token:
        return None
    parts = token.split(":")
    if len(parts) >= 2:
        return parts[1]
    return "unknown"
#endregion debug-point yis-setup


def format_bytes(bytes_val: int) -> str:
    """Форматирует байты в читаемый вид"""
    for unit in ["Б", "КБ", "МБ", "ГБ", "ТБ"]:
        if bytes_val < 1024.0:
            return f"{bytes_val:.2f} {unit}"
        bytes_val /= 1024.0
    return f"{bytes_val:.2f} ПБ"


def get_main_keyboard() -> ReplyKeyboardMarkup:
    """Создаёт основную клавиатуру с кнопками"""
    keyboard = [
        [KeyboardButton("🚀 Получить VPN")],
        [KeyboardButton("📄 Моя подписка")],
        [KeyboardButton("🆘 Поддержка")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def get_plan_selection_keyboard() -> ReplyKeyboardMarkup:
    """Создаёт клавиатуру выбора тарифа"""
    keyboard = [
        [KeyboardButton("1 месяц - 299 ₽")],
        [KeyboardButton("3 месяца - 810 ₽")],
        [KeyboardButton("🔙 Назад")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def get_confirmation_keyboard() -> ReplyKeyboardMarkup:
    """Создаёт клавиатуру подтверждения новой подписки"""
    keyboard = [
        [KeyboardButton("✅ Да, хочу купить ещё одно")],
        [KeyboardButton("📄 Посмотреть мои подписки")],
        [KeyboardButton("🔙 Назад")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_subscription_keyboard() -> ReplyKeyboardMarkup:
    """Создаёт клавиатуру для страницы подписки"""
    keyboard = [
        [KeyboardButton("🔄 Продлить подписку")],
        [KeyboardButton("🏠 Главное меню")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_extend_plan_keyboard() -> ReplyKeyboardMarkup:
    """Создаёт клавиатуру выбора плана для продления"""
    keyboard = [
        [KeyboardButton("1 месяц - 299 ₽")],
        [KeyboardButton("3 месяца - 810 ₽")],
        [KeyboardButton("🔙 Назад")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает команду /start"""
    user = update.effective_user
    if not user or not update.message:
        return
    #region debug-point yis-start
    _dbg("start", user_id=user.id, username=user.username, chat_id=update.effective_chat.id if update.effective_chat else None)
    #endregion debug-point yis-start

    welcome_text = f"""👋 Привет, {user.first_name}!

🚀 Добро пожаловать в наш VPN-сервис!

Здесь ты можешь быстро получить доступ к безопасному интернету с высокой скоростью.

📋 Что мы предлагаем:
• Безлимитный трафик
• 3 устройства на подписку
• Все протоколы подключения
• Быстрая техническая поддержка

Используй кнопки ниже, чтобы начать пользоваться VPN!
"""
    await update.message.reply_text(welcome_text, reply_markup=get_main_keyboard())


async def handle_get_vpn_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Начинает процесс создания подписки - проверяет активные подписки"""
    telegram_user = update.effective_user
    if not telegram_user or not update.message:
        return ConversationHandler.END

    user_id = telegram_user.id
    logger.info(f"Пользователь {user_id} открыл выбор тарифа")
    #region debug-point yis-entry
    _dbg("get_vpn_entry", user_id=user_id, username=telegram_user.username, text=update.message.text)
    #endregion debug-point yis-entry

    db = SessionLocal()
    try:
        vpn_service = VPNService(db)
        has_active = vpn_service.has_active_subscriptions(user_id)
        #region debug-point yis-has-active
        _dbg("has_active_checked", user_id=user_id, has_active=bool(has_active))
        #endregion debug-point yis-has-active

        if has_active:
            message = """👋 У вас уже есть активное подключение!

Ваша подписка доступна в разделе "📄 Моя подписка".

Хотите купить ещё одно подключение?
"""
            await update.message.reply_text(
                message,
                reply_markup=get_confirmation_keyboard(),
            )
            return CONFIRM_NEW_SUBSCRIPTION
        else:
            # Нет активных подписок - показываем выбор тарифа
            plan_text = """📋 Выбери тариф подписки:

1 месяц - 299 ₽
3 месяца - 810 ₽

💡 При оплате за 3 месяца - скидка!
"""
            await update.message.reply_text(plan_text, reply_markup=get_plan_selection_keyboard())
            return SELECTING_PLAN
    finally:
        db.close()


async def handle_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обрабатывает подтверждение новой подписки при наличии активной"""
    if not update.message:
        return ConversationHandler.END

    text = update.message.text.strip()

    if text == "✅ Да, хочу купить ещё одно":
        plan_text = """📋 Выбери тариф подписки:

1 месяц - 299 ₽
3 месяца - 810 ₽

💡 При оплате за 3 месяца - скидка!
"""
        await update.message.reply_text(plan_text, reply_markup=get_plan_selection_keyboard())
        return SELECTING_PLAN
    elif text == "📄 Посмотреть мои подписки":
        await handle_my_subscription(update, context)
        return ConversationHandler.END
    elif text == "🔙 Назад":
        await start(update, context)
        return ConversationHandler.END
    else:
        await update.message.reply_text("Пожалуйста, выбери вариант с кнопок ниже.")
        return CONFIRM_NEW_SUBSCRIPTION


async def handle_plan_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обрабатывает выбор тарифа и отправляет счёт на оплату"""
    telegram_user = update.effective_user
    if not telegram_user or not update.message:
        return ConversationHandler.END

    text = update.message.text.strip()
    user_id = telegram_user.id
    username = telegram_user.username or f"user_{user_id}"
    #region debug-point yis-plan-in
    _dbg(
        "plan_selection_in",
        user_id=user_id,
        username=username,
        text=text,
        chat_id=update.effective_chat.id if update.effective_chat else None,
    )
    #endregion debug-point yis-plan-in

    logger.info(f"Пользователь {user_id} нажал на текст: {repr(text)}")

    duration_months = 0
    price_amount = 0
    title = ""
    description = ""

    if "1 месяц" in text or "299 ₽" in text:
        duration_months = 1
        price_amount = PRICE_1_MONTH
        title = "VPN подписка на 1 месяц"
        description = "Безлимитный трафик, 3 устройства"
        logger.info(f"Пользователь {user_id} выбрал тариф на 1 месяц")
    elif "3 месяца" in text or "810 ₽" in text:
        duration_months = 3
        price_amount = PRICE_3_MONTHS
        title = "VPN подписка на 3 месяца"
        description = "Безлимитный трафик, 3 устройства"
        logger.info(f"Пользователь {user_id} выбрал тариф на 3 месяца")
    elif text == "🔙 Назад":
        await start(update, context)
        return ConversationHandler.END
    else:
        await update.message.reply_text("Пожалуйста, выбери тариф с кнопок ниже.")
        return SELECTING_PLAN

    # Сохраняем данные в контексте
    context.user_data["duration_months"] = duration_months
    context.user_data["username"] = username

    # Подготовка цен
    prices = [LabeledPrice("К оплате", price_amount)]

    logger.info(f"Отправляю инвойс: {title}, цена: {price_amount} копеек")
    logger.info(f"Используемый provider token: {repr(YOO_PAYMENT_TOKEN)}")

    try:
        #region debug-point yis-send-invoice-attempt
        _dbg(
            "send_invoice_attempt",
            user_id=user_id,
            duration_months=duration_months,
            price_amount=price_amount,
            currency=CURRENCY,
            provider_kind=_provider_kind(YOO_PAYMENT_TOKEN),
            start_parameter="test",
            prices=[{"label": p.label, "amount": p.amount} for p in prices],
        )
        #endregion debug-point yis-send-invoice-attempt
        await context.bot.send_invoice(
            chat_id=update.effective_chat.id,
            title=title,
            description=description,
            payload=json.dumps(
                {
                    "user_id": user_id,
                    "duration_months": duration_months,
                    "username": username,
                },
                ensure_ascii=False,
            ),
            provider_token=YOO_PAYMENT_TOKEN,
            currency=CURRENCY,
            start_parameter="test",
            prices=prices,
        )
        logger.info(f"Инвойс успешно отправлен пользователю {user_id}")
        #region debug-point yis-send-invoice-ok
        _dbg("send_invoice_ok", user_id=user_id)
        #endregion debug-point yis-send-invoice-ok
    except BadRequest as e:
        logger.exception(f"Ошибка при отправке инвойса пользователю {user_id}: {e}")
        #region debug-point yis-send-invoice-error
        _dbg(
            "send_invoice_error",
            user_id=user_id,
            error_type=type(e).__name__,
            error=str(e),
            traceback="".join(traceback.format_exception(type(e), e, e.__traceback__)),
        )
        #endregion debug-point yis-send-invoice-error
        bot_username = None
        try:
            me = await context.bot.get_me()
            bot_username = me.username
        except Exception:
            bot_username = None
        bot_hint = f"@{bot_username}" if bot_username else "этого бота"
        await update.message.reply_text(
            f"❌ Не удалось выставить счёт.\n"
            f"Текст ошибки от Telegram: {str(e)}\n\n"
            f"Используемый токен: {repr(YOO_PAYMENT_TOKEN)}\n\n"
            "Как исправить:\n"
            "1) BotFather → /mybots → выбери @abusee_vpnbot\n"
            "2) Payments → проверь, что ЮKassa: тест подключен (статус Connected)\n"
            "3) Если не подключен → Connect ЮKassa: тест → авторизуйся в ЮKassa\n"
            "4) Скопируй provider token из BotFather (формат #####:TEST:####)\n"
            "5) Вставь его в .env в YOO_PAYMENT_TOKEN\n"
            "6) Перезапусти бота\n",
            reply_markup=get_main_keyboard(),
        )
    except Exception as e:
        logger.exception(f"Ошибка при отправке инвойса пользователю {user_id}: {e}")
        #region debug-point yis-send-invoice-error-unknown
        _dbg(
            "send_invoice_error",
            user_id=user_id,
            error_type=type(e).__name__,
            error=str(e),
            traceback="".join(traceback.format_exception(type(e), e, e.__traceback__)),
        )
        #endregion debug-point yis-send-invoice-error-unknown
        await update.message.reply_text(
            f"❌ Произошла ошибка при отправке счета. Напиши в поддержку: @{TELEGRAM_ADMIN_ID}",
            reply_markup=get_main_keyboard(),
        )

    return ConversationHandler.END


async def pre_checkout_query(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает запрос перед оплатой - подтверждаем, что всё ок"""
    pre_checkout_query = update.pre_checkout_query
    logger.info(f"Получен pre_checkout_query от пользователя {pre_checkout_query.from_user.id}")
    #region debug-point yis-precheckout-in
    _dbg(
        "pre_checkout_query",
        user_id=pre_checkout_query.from_user.id,
        currency=pre_checkout_query.currency,
        total_amount=pre_checkout_query.total_amount,
        invoice_payload=pre_checkout_query.invoice_payload,
    )
    #endregion debug-point yis-precheckout-in

    # Подтверждаем оплату (обязательно в течение 10 секунд!)
    try:
        await pre_checkout_query.answer(ok=True)
        logger.info("pre_checkout_query.answer(ok=True) отправлен")
        #region debug-point yis-precheckout-ok
        _dbg("pre_checkout_answer_ok", user_id=pre_checkout_query.from_user.id)
        #endregion debug-point yis-precheckout-ok
    except Exception as e:
        logger.exception(f"Ошибка при ответе на pre_checkout_query: {e}")
        #region debug-point yis-precheckout-error
        _dbg(
            "pre_checkout_answer_error",
            user_id=pre_checkout_query.from_user.id,
            error_type=type(e).__name__,
            error=str(e),
        )
        #endregion debug-point yis-precheckout-error
        await pre_checkout_query.answer(ok=False, error_message="Ошибка оплаты, попробуйте позже")


async def successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает успешную оплату - создаём VPN-подписку или продлеваем"""
    payment = update.message.successful_payment
    user_id = update.effective_user.id
    logger.info(f"Успешная оплата от пользователя {user_id}!")
    #region debug-point yis-success-in
    _dbg(
        "successful_payment",
        user_id=user_id,
        total_amount=payment.total_amount,
        currency=payment.currency,
        provider_payment_charge_id=payment.provider_payment_charge_id,
    )
    #endregion debug-point yis-success-in

    # Достаём данные из payload
    try:
        payload = json.loads(payment.invoice_payload)
        duration_months = payload["duration_months"]
        is_extend = payload.get("is_extend", False)
        logger.info(f"Данные из payload: duration={duration_months}, is_extend={is_extend}")
    except Exception as e:
        logger.exception(f"Ошибка при парсинге payload: {e}")
        await update.message.reply_text(
            "❌ Ошибка при обработке оплаты, но оплата прошла! Напиши в поддержку",
            reply_markup=get_main_keyboard()
        )
        return

    db = SessionLocal()
    processing_msg = None

    try:
        vpn_service = VPNService(db)

        if is_extend:
            # Продлеваем подписку
            processing_msg = await update.message.reply_text("⏳ Оплата успешна! Продлеваем подписку...")

            extend_user_db_id = payload.get("extend_user_db_id")
            user = db.query(User).filter(User.id == extend_user_db_id).first()

            if not user:
                # Если не нашли по ID, ищем последнюю подписку пользователя
                user = db.query(User).filter(User.telegram_id == user_id).order_by(User.created_at.desc()).first()

            if user:
                updated_user = vpn_service.extend_subscription(user, duration_months)
                
                # Сбрасываем флаги напоминаний, так как подписка продлена
                updated_user.reminder_3d_sent = False
                updated_user.reminder_1d_sent = False
                db.commit()
                db.refresh(updated_user)

                await processing_msg.delete()
                expire_str = updated_user.expire_at.strftime("%d.%m.%Y %H:%M")
                duration_word = "месяц" if duration_months == 1 else "месяца"

                message = f"""✅ Подписка успешно продлена!

📅 Добавлено: {duration_months} {duration_word}
📅 Новая дата окончания: {expire_str}

Ты можешь продолжать пользоваться VPN! 🚀
"""
                await update.message.reply_text(message, reply_markup=get_main_keyboard())
            else:
                await processing_msg.delete()
                await update.message.reply_text(
                    "❌ Ошибка при продлении подписки! Напиши в поддержку",
                    reply_markup=get_main_keyboard()
                )
        else:
            # Создаём новую подписку
            processing_msg = await update.message.reply_text("⏳ Оплата успешна! Подготавливаем VPN...")
            username = payload["username"]
            user, _, subscription_url = vpn_service.create_new_user_with_duration(
                user_id, username, duration_months
            )

            await processing_msg.delete()

            if user and subscription_url:
                expire_str = user.expire_at.strftime("%d.%m.%Y %H:%M")
                duration_word = "месяц" if duration_months == 1 else "месяца"

                message = f"""🎉 Оплата успешна! Твой VPN готов!

📅 Срок подписки: {duration_months} {duration_word}
📅 Действует до: {expire_str}
📊 Трафик: Безлимитный
📱 Устройства: 3

📖 [Инструкция к установке]({INSTALLATION_GUIDE_URL})

🔗 Ссылка для подключения:
`{subscription_url}`

Удачного использования! 🚀
"""
                await update.message.reply_text(
                    message,
                    parse_mode="Markdown",
                    reply_markup=get_main_keyboard()
                )
            else:
                await update.message.reply_text(
                    "❌ Ошибка при создании подписки, но оплата прошла! Напиши в поддержку",
                    reply_markup=get_main_keyboard()
                )

    except Exception as e:
        logger.exception(f"Ошибка при обработке оплаты: {e}")
        try:
            if processing_msg:
                await processing_msg.delete()
        except Exception:
            pass
        await update.message.reply_text(
            "❌ Ошибка при обработке оплаты! Напиши в поддержку",
            reply_markup=get_main_keyboard()
        )
    finally:
        db.close()


async def handle_my_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает нажатие кнопки "📄 Моя подписка" """
    telegram_user = update.effective_user
    if not telegram_user or not update.message:
        return

    user_id = telegram_user.id
    logger.info(f"Запрос подписки от пользователя {user_id}")

    db = SessionLocal()
    xui_client = XUIClient()

    try:
        users = (
            db.query(User)
            .filter(User.telegram_id == user_id)
            .order_by(User.created_at.desc())
            .all()
        )

        if not users:
            await update.message.reply_text(
                "📄 У тебя пока нет подписок. Нажми \"🚀 Получить VPN\", чтобы создать!",
                reply_markup=get_main_keyboard(),
            )
            return

        # Получаем самую свежую подписку
        user = users[0]
        expire_str = user.expire_at.strftime("%d.%m.%Y %H:%M")

        # Попробуем получить статистику из 3x-ui
        stats = None
        try:
            stats = xui_client.get_client_stats(user.vpn_email)
        except Exception as e:
            logger.warning(f"Не удалось получить статистику: {e}")

        traffic_used = "Не указано"
        if stats:
            total_bytes = stats.get("total_up", 0) + stats.get("total_down", 0)
            traffic_used = format_bytes(total_bytes)

        message = f"""📄 Твоя подписка:

📅 Действует до: {expire_str}
📊 Трафик: Безлимитный
📊 Использовано: {traffic_used}
📱 Устройства: {stats.get("device_limit", 3) if stats else 3}
📱 Статус: {"✅ Активна" if user.is_active else "❌ Неактивна"}

📖 [Инструкция к установке]({INSTALLATION_GUIDE_URL})

🔗 Ссылка для подключения:
`{user.subscription_url}`
"""
        await update.message.reply_text(
            message,
            parse_mode="Markdown",
            reply_markup=get_subscription_keyboard()
        )

    except Exception as e:
        logger.exception(f"Ошибка при получении подписки: {e}")
        await update.message.reply_text(
            "❌ Не удалось загрузить подписку. Попробуй позже.",
            reply_markup=get_main_keyboard(),
        )
    finally:
        db.close()

async def handle_extend_subscription_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Начинает процесс продления подписки"""
    telegram_user = update.effective_user
    if not telegram_user or not update.message:
        return ConversationHandler.END

    user_id = telegram_user.id
    logger.info(f"Пользователь {user_id} хочет продлить подписку")

    db = SessionLocal()
    try:
        # Проверяем, есть ли у пользователя подписка
        users = (
            db.query(User)
            .filter(User.telegram_id == user_id)
            .order_by(User.created_at.desc())
            .all()
        )

        if not users:
            await update.message.reply_text(
                "📄 У тебя пока нет подписок для продления!",
                reply_markup=get_main_keyboard(),
            )
            return ConversationHandler.END

        # Сохраняем ID подписки в контексте
        context.user_data["extend_user_id"] = users[0].id

        await update.message.reply_text(
            "🔄 Выбери на сколько хочешь продлить подписку:",
            reply_markup=get_extend_plan_keyboard()
        )
        return SELECTING_EXTEND_PLAN

    except Exception as e:
        logger.exception(f"Ошибка при начале продления: {e}")
        await update.message.reply_text(
            "❌ Произошла ошибка. Попробуй позже.",
            reply_markup=get_main_keyboard(),
        )
        return ConversationHandler.END
    finally:
        db.close()

async def handle_extend_plan_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обрабатывает выбор плана для продления и отправляет инвойс"""
    telegram_user = update.effective_user
    if not telegram_user or not update.message:
        return ConversationHandler.END

    text = update.message.text.strip()
    user_id = telegram_user.id

    duration_months = 0
    price_amount = 0
    title = ""
    description = ""

    if "1 месяц" in text or "299 ₽" in text:
        duration_months = 1
        price_amount = PRICE_1_MONTH
        title = "Продление подписки на 1 месяц"
        description = "Безлимитный трафик, 3 устройства"
        logger.info(f"Пользователь {user_id} выбрал продление на 1 месяц")
    elif "3 месяца" in text or "810 ₽" in text:
        duration_months = 3
        price_amount = PRICE_3_MONTHS
        title = "Продление подписки на 3 месяца"
        description = "Безлимитный трафик, 3 устройства"
        logger.info(f"Пользователь {user_id} выбрал продление на 3 месяца")
    elif text == "🔙 Назад":
        await handle_my_subscription(update, context)
        return ConversationHandler.END
    else:
        await update.message.reply_text("Пожалуйста, выбери вариант из кнопок ниже.")
        return SELECTING_EXTEND_PLAN

    # Сохраняем данные в контексте
    context.user_data["extend_duration"] = duration_months

    # Подготовка цен
    prices = [LabeledPrice("К оплате", price_amount)]

    logger.info(f"Отправляю инвойс для продления: {title}, цена: {price_amount} копеек")

    try:
        await context.bot.send_invoice(
            chat_id=update.effective_chat.id,
            title=title,
            description=description,
            payload=json.dumps(
                {
                    "user_id": user_id,
                    "duration_months": duration_months,
                    "is_extend": True,
                    "extend_user_db_id": context.user_data.get("extend_user_id")
                },
                ensure_ascii=False,
            ),
            provider_token=YOO_PAYMENT_TOKEN,
            currency=CURRENCY,
            start_parameter="test",
            prices=prices,
        )
        logger.info(f"Инвойс для продления успешно отправлен пользователю {user_id}")
    except Exception as e:
        logger.exception(f"Ошибка при отправке инвойса для продления: {e}")
        await update.message.reply_text(
            f"❌ Произошла ошибка при отправке счета. Напиши в поддержку: @{TELEGRAM_ADMIN_ID}",
            reply_markup=get_main_keyboard()
        )

    return ConversationHandler.END


async def handle_support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает нажатие кнопки "🆘 Поддержка" """
    if not update.message:
        return

    support_text = f"""🆘 Поддержка

Если возникли вопросы или проблемы с VPN:

👉 Напиши администратору: @{TELEGRAM_ADMIN_ID}

Оперативно поможем!
"""
    await update.message.reply_text(support_text, reply_markup=get_main_keyboard())


async def handle_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Отменяет разговор и возвращает главное меню"""
    await start(update, context)
    return ConversationHandler.END


async def handle_unknown_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает текстовые сообщения вне разговора"""
    if not update.message or not update.message.text:
        return

    text = update.message.text.strip()

    if text == "🚀 Получить VPN":
        # Этот случай обрабатывается ConversationHandler, но на всякий случай
        await start(update, context)
    elif text == "📄 Моя подписка":
        await handle_my_subscription(update, context)
    elif text == "🆘 Поддержка":
        await handle_support(update, context)
    else:
        await start(update, context)


async def send_reminders(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Проверяет и отправляет напоминания о необходимости продлить подписку"""
    db = SessionLocal()
    try:
        now = datetime.now()
        three_days_later = now + timedelta(days=3)
        one_day_later = now + timedelta(days=1)

        # Ищем пользователей, у которых подписка истекает через 3 дня и напоминание не отправлено
        users_3d = db.query(User).filter(
            User.expire_at >= three_days_later - timedelta(hours=1),
            User.expire_at <= three_days_later + timedelta(hours=1),
            User.reminder_3d_sent == False,
            User.is_active == True
        ).all()

        for user in users_3d:
            try:
                await context.bot.send_message(
                    chat_id=user.telegram_id,
                    text=f"""⚠️ Напоминание!

Твоя подписка на VPN истекает через 3 дня!
📅 Дата окончания: {user.expire_at.strftime("%d.%m.%Y %H:%M")}

Чтобы не остаться без VPN, продли подписку прямо сейчас в разделе "📄 Моя подписка"!
"""
                )
                user.reminder_3d_sent = True
                db.commit()
                logger.info(f"Отправлено напоминание за 3 дня пользователю {user.telegram_id}")
            except Exception as e:
                logger.exception(f"Ошибка при отправке напоминания за 3 дня пользователю {user.telegram_id}: {e}")

        # Ищем пользователей, у которых подписка истекает через 1 день и напоминание не отправлено
        users_1d = db.query(User).filter(
            User.expire_at >= one_day_later - timedelta(hours=1),
            User.expire_at <= one_day_later + timedelta(hours=1),
            User.reminder_1d_sent == False,
            User.is_active == True
        ).all()

        for user in users_1d:
            try:
                await context.bot.send_message(
                    chat_id=user.telegram_id,
                    text=f"""🔴 Внимание!

Твоя подписка на VPN истекает уже завтра!
📅 Дата окончания: {user.expire_at.strftime("%d.%m.%Y %H:%M")}

Продли подписку прямо сейчас в разделе "📄 Моя подписка", чтобы не остаться без VPN!
"""
                )
                user.reminder_1d_sent = True
                db.commit()
                logger.info(f"Отправлено напоминание за 1 день пользователю {user.telegram_id}")
            except Exception as e:
                logger.exception(f"Ошибка при отправке напоминания за 1 день пользователю {user.telegram_id}: {e}")

    except Exception as e:
        logger.exception(f"Ошибка при проверке напоминаний: {e}")
    finally:
        db.close()


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    err = context.error
    logger.exception("Bot error", exc_info=err)
    #region debug-point yis-unhandled
    _dbg(
        "unhandled_error",
        error_type=type(err).__name__ if err else None,
        error=str(err) if err else None,
    )
    #endregion debug-point yis-unhandled
    if isinstance(err, Conflict):
        logger.error(
            "Telegram getUpdates conflict: запущен другой экземпляр бота с этим токеном. Останови его."
        )
        try:
            await context.application.stop()
        except Exception:
            pass


def main() -> None:
    """Запускает бота"""
    if not TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN не установлен в .env!")
        return
    if not YOO_PAYMENT_TOKEN or YOO_PAYMENT_TOKEN == "ВСТАВЬ_ТВОЙ_ПЛАТЁЖНЫЙ_ТОКЕН":
        logger.error("YOO_PAYMENT_TOKEN не установлен в .env!")
        return

    lock_path = Path(__file__).with_name(".bot.lock")
    lock_file = open(lock_path, "w")
    try:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_file.write(str(os.getpid()))
        lock_file.flush()
    except OSError:
        logger.error("Бот уже запущен (lock). Останови другие экземпляры и запусти снова.")
        return

    # Создаём таблицы БД
    Base.metadata.create_all(bind=engine)
    logger.info("✅ База данных инициализирована")

    logger.info("🔧 Создаём приложение бота...")
    application = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()

    # ConversationHandler для выбора тарифа и подтверждения
    conv_handler = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex(r"^🚀 Получить VPN$"), handle_get_vpn_start)],
        states={
            CONFIRM_NEW_SUBSCRIPTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_confirmation)
            ],
            SELECTING_PLAN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_plan_selection)
            ],
            SELECTING_EXTEND_PLAN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_extend_plan_selection)
            ],
        },
        fallbacks=[
            MessageHandler(filters.Regex(r"^🔙 Назад$"), handle_cancel),
            CommandHandler("start", handle_cancel),
        ],
    )

    # ConversationHandler для продления подписки
    extend_conv_handler = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex(r"^🔄 Продлить подписку$"), handle_extend_subscription_start)],
        states={
            SELECTING_EXTEND_PLAN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_extend_plan_selection)
            ],
        },
        fallbacks=[
            MessageHandler(filters.Regex(r"^🔙 Назад$"), handle_cancel),
            CommandHandler("start", handle_cancel),
        ],
    )

    application.add_handler(conv_handler)
    application.add_handler(extend_conv_handler)
    application.add_handler(CommandHandler("start", start))
    application.add_handler(
        MessageHandler(filters.Regex(r"^📄 Моя подписка$"), handle_my_subscription)
    )
    application.add_handler(MessageHandler(filters.Regex(r"^🆘 Поддержка$"), handle_support))
    application.add_handler(MessageHandler(filters.Regex(r"^🏠 Главное меню$"), start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_unknown_text))

    # Обработчики платежей
    application.add_handler(PreCheckoutQueryHandler(pre_checkout_query))
    application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))
    application.add_error_handler(on_error)

    # Запускаем job для проверки напоминаний каждые 2 часа
    job_queue = application.job_queue
    job_queue.run_repeating(send_reminders, interval=7200, first=10)

    # Запускаем бота
    logger.info("🚀 Запускаем бота...")
    try:
        application.run_polling(drop_pending_updates=True)
    except Conflict:
        logger.error("Запущен другой экземпляр бота с этим токеном (getUpdates conflict). Останови его и перезапусти.")


if __name__ == "__main__":
    main()
