import uuid
import logging
from datetime import datetime, timedelta
from typing import Tuple

from sqlalchemy.orm import Session

from app.models.user import User
from app.services.xui_client import XUIClient

logger = logging.getLogger(__name__)


class VPNService:
    DEFAULT_MONTHS = 1
    DEFAULT_TRAFFIC_LIMIT_GB = 0  # Безлимитный трафик
    DEFAULT_DEVICE_LIMIT = 3
    DEFAULT_PROTOCOL = "all"

    def __init__(self, db: Session):
        self.db = db
        self.xui_client = XUIClient()
        # Находим vless inbound автоматически
        self.inbound_id = self.xui_client.find_vless_inbound() or 1
        logger.info(f"Using inbound ID: {self.inbound_id}")
    
    def has_active_subscriptions(self, telegram_id: int) -> bool:
        """Проверяет, есть ли у пользователя активные подписки"""
        now = datetime.now()
        active_users = (
            self.db.query(User)
            .filter(
                User.telegram_id == telegram_id,
                User.is_active == True,
                User.expire_at > now
            )
            .all()
        )
        return len(active_users) > 0
    
    def create_new_user_with_duration(
        self, telegram_id: int, base_username: str, duration_months: int
    ) -> Tuple[User, str, str]:
        """Создаёт нового пользователя с указанной длительностью подписки"""
        username = self._build_username(telegram_id, base_username)
        user_uuid = str(uuid.uuid4())
        expire_at = datetime.now() + timedelta(days=30 * duration_months)
        expire_timestamp = int(expire_at.timestamp() * 1000)

        logger.info(f"Creating new user for telegram_id {telegram_id}: {username} for {duration_months} months")

        db_user = User(
            telegram_id=telegram_id,
            username=username,
            vpn_email=username,
            uuid=user_uuid,
            expire_at=expire_at,
            traffic_limit_gb=0,  # Безлимитный трафик
            device_limit=3,  # 3 устройства
            is_active=True,
            protocol=self.DEFAULT_PROTOCOL
        )

        self.db.add(db_user)
        self.db.commit()
        self.db.refresh(db_user)

        vless_url = ""
        subscription_url = ""
        try:
            subscription_url = self.xui_client.add_client_to_all_inbounds(
                email=username,
                uuid=user_uuid,
                expire_timestamp=expire_timestamp,
                device_limit=3,  # 3 устройства
                enable=True
            )

            db_user.subscription_url = subscription_url
            self.db.commit()
            self.db.refresh(db_user)

            logger.info("✅ User created and added to all inbounds")

            # Попробуем получить vless_url
            try:
                inbound = self.xui_client.get_inbound_by_id(self.inbound_id)
                existing_client = self.xui_client.get_client_from_inbound(self.inbound_id, username)
                if inbound and existing_client:
                    vless_url = self.xui_client.generate_vless_url(inbound, existing_client)
            except Exception as vless_err:
                logger.warning(f"Could not generate vless_url: {vless_err}", exc_info=True)

        except Exception as e:
            logger.error(f"Error working with XUI: {str(e)}", exc_info=True)
            db_user.is_active = False
            self.db.commit()
            self.db.refresh(db_user)
            raise

        return db_user, vless_url, subscription_url
    
    def extend_subscription(self, user: User, duration_months: int) -> User:
        """Продлевает подписку пользователя на указанное количество месяцев"""
        now = datetime.now()
        # Если подписка уже истекла, продлеваем от текущего момента
        if user.expire_at < now:
            new_expire_at = now + timedelta(days=30 * duration_months)
        else:
            new_expire_at = user.expire_at + timedelta(days=30 * duration_months)
        
        new_expire_timestamp = int(new_expire_at.timestamp() * 1000)
        
        logger.info(f"Extending subscription for user {user.username} for {duration_months} months, new expire: {new_expire_at}")
        
        user.expire_at = new_expire_at
        
        # Обновляем в XUI
        try:
            self.xui_client.update_client_expire(
                email=user.vpn_email,
                expire_timestamp=new_expire_timestamp
            )
            logger.info("✅ Client expire updated in XUI")
        except Exception as e:
            logger.error(f"Error updating client in XUI: {str(e)}", exc_info=True)
            raise
        
        self.db.commit()
        self.db.refresh(user)
        
        return user

    def _build_username(self, telegram_id: int, base_username: str) -> str:
        """Формирует уникальное имя пользователя на основе username: username_1, username_2"""
        # Очищаем username - оставляем только буквы и цифры
        clean_username = "".join(c for c in base_username if c.isalnum() or c in ('_', '-')).lower()
        if not clean_username:
            clean_username = f"user_{telegram_id}"
        
        prefix = f"{clean_username}_"
        existing_usernames = [
            username
            for (username,) in self.db.query(User.username)
            .filter(User.telegram_id == telegram_id)
            .all()
            if username and username.startswith(prefix)
        ]

        next_index = 1
        for username in existing_usernames:
            suffix = username.removeprefix(prefix)
            if suffix.isdigit():
                next_index = max(next_index, int(suffix) + 1)

        return f"{prefix}{next_index}"

    def get_or_create_user_for_telegram(self, telegram_id: int, base_username: str) -> Tuple[User, str, str]:
        """
        Получает существующего пользователя или создаёт нового
        Возвращает (user, vless_url, subscription_url)
        """
        # Сначала ищем существующего пользователя
        existing_user = self.db.query(User).filter(User.telegram_id == telegram_id).order_by(User.created_at.desc()).first()
        
        if existing_user and existing_user.subscription_url:
            logger.info(f"Found existing user for telegram_id {telegram_id}: {existing_user.username}")
            return existing_user, "", existing_user.subscription_url
        
        # Создаём нового
        username = self._build_username(telegram_id, base_username)
        user_uuid = str(uuid.uuid4())
        expire_at = datetime.now() + timedelta(days=30 * self.DEFAULT_MONTHS)
        expire_timestamp = int(expire_at.timestamp() * 1000)

        logger.info(f"Creating new user for telegram_id {telegram_id}: {username}")

        db_user = User(
            telegram_id=telegram_id,
            username=username,
            vpn_email=username,
            uuid=user_uuid,
            expire_at=expire_at,
            traffic_limit_gb=2000,  # 2000 GB по умолчанию
            device_limit=self.DEFAULT_DEVICE_LIMIT,
            is_active=True,
            protocol=self.DEFAULT_PROTOCOL
        )

        self.db.add(db_user)
        self.db.commit()
        self.db.refresh(db_user)

        vless_url = ""
        subscription_url = ""
        try:
            subscription_url = self.xui_client.add_client_to_all_inbounds(
                email=username,
                uuid=user_uuid,
                expire_timestamp=expire_timestamp,
                device_limit=self.DEFAULT_DEVICE_LIMIT,
                enable=True
            )

            db_user.subscription_url = subscription_url
            self.db.commit()
            self.db.refresh(db_user)

            logger.info("✅ User created and added to all inbounds")

            # Попробуем получить vless_url, но если не получится - не страшно
            try:
                inbound = self.xui_client.get_inbound_by_id(self.inbound_id)
                existing_client = self.xui_client.get_client_from_inbound(self.inbound_id, username)
                if inbound and existing_client:
                    vless_url = self.xui_client.generate_vless_url(inbound, existing_client)
            except Exception as vless_err:
                logger.warning(f"Could not generate vless_url: {vless_err}", exc_info=True)

        except Exception as e:
            logger.error(f"Error working with XUI: {str(e)}", exc_info=True)
            db_user.is_active = False
            self.db.commit()
            self.db.refresh(db_user)
            raise

        return db_user, vless_url, subscription_url
