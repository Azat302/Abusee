from sqlalchemy import Column, Integer, String, DateTime, Boolean
from sqlalchemy.sql import func
from app.database.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(Integer, index=True, nullable=True)  # No more unique!
    username = Column(String, index=True)
    vpn_email = Column(String, unique=True, index=True, nullable=True)
    uuid = Column(String, unique=True, index=True)
    expire_at = Column(DateTime)
    traffic_limit_gb = Column(Integer)
    xui_client_id = Column(Integer, nullable=True)
    subscription_url = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    protocol = Column(String, nullable=True, default="vless")
    device_limit = Column(Integer, default=1)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    reminder_3d_sent = Column(Boolean, default=False)
    reminder_1d_sent = Column(Boolean, default=False)
